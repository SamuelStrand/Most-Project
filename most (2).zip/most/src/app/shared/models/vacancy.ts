export class Vacancy{
    id!:number;
    name!:string;
    salary!:string;
    Payments!:string;
    workexp!:string;
    schedule!:number;
    whours!:number;
    favorite:boolean = false;
    imageUrl!:string;
    wformat!:string;
}
